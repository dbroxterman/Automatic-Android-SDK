package com.automatic.sample;

import android.app.Activity;

/**
 * Created by stevenzhou on 12/8/15.
 */
public class TestActivity extends Activity {
}
